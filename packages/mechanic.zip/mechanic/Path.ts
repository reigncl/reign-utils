export interface Path {
  type: string;
  value: string;
}
