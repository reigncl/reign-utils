export type TypePart = "discount" |
  "discountAmount" |
  "literal" |
  "m" |
  "minimumAmount" |
  "nProducts" |
  "offer" |
  "ref" |
  "input" |
  "nOffer" |
  "new_line" |
  "price" |
  "amountSuffix";
